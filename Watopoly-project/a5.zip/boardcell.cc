#include "boardcell.h"

int BoardCell::getImprovs() { return 0; }
void BoardCell::resetImprovs() {}
int BoardCell::getImprovCost() {return 0;}
void BoardCell::setImprovs(int amt) {}
